"""
Install SentencePiece for T5 tokenizer
"""

import subprocess
import sys

def install_sentencepiece():
    """Install SentencePiece package"""
    print("Installing SentencePiece...")
    
    try:
        # Try to import first
        import sentencepiece
        print("✅ SentencePiece already installed")
        return True
    except ImportError:
        print("❌ SentencePiece not found, installing...")
    
    try:
        # Install using pip
        result = subprocess.run([
            sys.executable, "-m", "pip", "install", "sentencepiece"
        ], capture_output=True, text=True, check=True)
        
        print("✅ SentencePiece installed successfully")
        print("Output:", result.stdout)
        
        # Test import
        import sentencepiece
        print("✅ SentencePiece import test successful")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Installation failed: {e}")
        print("Error output:", e.stderr)
        return False
    except ImportError as e:
        print(f"❌ Import test failed: {e}")
        return False

def test_t5_tokenizer():
    """Test if T5 tokenizer works now"""
    print("\nTesting T5 tokenizer...")
    
    try:
        from transformers import T5Tokenizer
        tokenizer = T5Tokenizer.from_pretrained('t5-small')
        
        # Test tokenization
        test_text = "Question: What is multithreading?"
        tokens = tokenizer(test_text, return_tensors='pt')
        
        print("✅ T5 tokenizer working successfully")
        print(f"Test tokenization shape: {tokens['input_ids'].shape}")
        return True
        
    except Exception as e:
        print(f"❌ T5 tokenizer test failed: {e}")
        return False

if __name__ == "__main__":
    print("🔧 Installing SentencePiece for T5 Training")
    print("="*50)
    
    if install_sentencepiece():
        if test_t5_tokenizer():
            print("\n🎉 SUCCESS! Ready for training")
            print("Now you can run: python fixed_trainer.py")
        else:
            print("\n⚠️ SentencePiece installed but T5 tokenizer still has issues")
    else:
        print("\n❌ Failed to install SentencePiece")
        print("Try manually: pip install sentencepiece")
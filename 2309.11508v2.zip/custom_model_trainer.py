"""
Custom T5 Model Trainer for OS Answer Grading
Trains specifically on YOUR dataset to learn YOUR grading patterns
"""

import torch
from torch.utils.data import Dataset, DataLoader
import pandas as pd
import numpy as np
from transformers import T5ForConditionalGeneration, T5Tokenizer, AdamW
import re
import os
import json
from datetime import datetime
from tqdm import tqdm

class OSGradingDataset(Dataset):
    """Dataset for OS grading - learns from YOUR specific grading examples"""
    
    def __init__(self, data_df, tokenizer, max_input_length=512, max_target_length=256):
        self.data = data_df.reset_index(drop=True)
        self.tokenizer = tokenizer
        self.max_input_length = max_input_length
        self.max_target_length = max_target_length
        
        print(f"Dataset created with {len(self.data)} examples")
        print(f"Sample input: {self.data.iloc[0]['input_text'][:100]}...")
        print(f"Sample target: {self.data.iloc[0]['target_text'][:100]}...")
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        row = self.data.iloc[idx]
        
        input_text = str(row['input_text'])
        target_text = str(row['target_text'])
        
        # Tokenize input
        input_encoding = self.tokenizer(
            input_text,
            max_length=self.max_input_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        # Tokenize target
        target_encoding = self.tokenizer(
            target_text,
            max_length=self.max_target_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': input_encoding['input_ids'].flatten(),
            'attention_mask': input_encoding['attention_mask'].flatten(),
            'labels': target_encoding['input_ids'].flatten()
        }

class CustomOSGradingTrainer:
    """
    Custom trainer that learns YOUR specific grading patterns
    """
    
    def __init__(self, model_name='t5-small'):
        """Initialize with a smaller, faster model"""
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        print(f"Using device: {self.device}")
        
        # Load model and tokenizer
        print(f"Loading {model_name} model...")
        self.tokenizer = T5Tokenizer.from_pretrained(model_name)
        self.model = T5ForConditionalGeneration.from_pretrained(model_name)
        self.model.to(self.device)
        
        # Add special tokens for our task
        special_tokens = ['<question>', '<answer>', '<context>', '<score>', '<feedback>']
        self.tokenizer.add_tokens(special_tokens)
        self.model.resize_token_embeddings(len(self.tokenizer))
        
        print("Model initialized successfully!")
    
    def load_data(self):
        """Load and prepare training data"""
        print("Loading training data...")
        
        # Load your processed data
        train_df = pd.read_csv("c:\\Users\\vinay\\Desktop\\research paper\\train_data.csv")
        val_df = pd.read_csv("c:\\Users\\vinay\\Desktop\\research paper\\val_data.csv")
        
        print(f"Training samples: {len(train_df)}")
        print(f"Validation samples: {len(val_df)}")
        
        # Create datasets
        self.train_dataset = OSGradingDataset(train_df, self.tokenizer)
        self.val_dataset = OSGradingDataset(val_df, self.tokenizer)
        
        # Create data loaders
        self.train_loader = DataLoader(
            self.train_dataset, 
            batch_size=2,  # Small batch size for stability
            shuffle=True
        )
        self.val_loader = DataLoader(
            self.val_dataset, 
            batch_size=2, 
            shuffle=False
        )
        
        return train_df, val_df
    
    def extract_score_from_prediction(self, prediction):
        """Extract score from model prediction"""
        # Look for score patterns
        patterns = [
            r'Score:\s*(\d+)/5',
            r'Score:\s*(\d+)',
            r'(\d+)/5',
            r'scored?\s*(\d+)'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, prediction, re.IGNORECASE)
            if match:
                score = int(match.group(1))
                return min(max(score, 0), 5)  # Ensure 0-5 range
        
        return 0  # Default if no score found
    
    def evaluate_model(self):
        """Evaluate model performance on validation set"""
        self.model.eval()
        predictions = []
        actuals = []
        
        print("Evaluating model...")
        
        with torch.no_grad():
            for batch in tqdm(self.val_loader, desc="Evaluating"):
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                
                # Generate predictions
                generated = self.model.generate(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    max_length=256,
                    num_beams=4,
                    early_stopping=True,
                    temperature=0.7,
                    do_sample=True
                )
                
                # Decode predictions
                for i in range(len(generated)):
                    pred_text = self.tokenizer.decode(generated[i], skip_special_tokens=True)
                    pred_score = self.extract_score_from_prediction(pred_text)
                    predictions.append(pred_score)
                    
                    # Get actual score from labels
                    actual_text = self.tokenizer.decode(batch['labels'][i], skip_special_tokens=True)
                    actual_score = self.extract_score_from_prediction(actual_text)
                    actuals.append(actual_score)
        
        # Calculate metrics
        predictions = np.array(predictions)
        actuals = np.array(actuals)
        
        mae = np.mean(np.abs(predictions - actuals))
        exact_match = np.mean(predictions == actuals)
        within_1 = np.mean(np.abs(predictions - actuals) <= 1)
        
        return {
            'mae': mae,
            'exact_match': exact_match,
            'within_1_point': within_1,
            'predictions': predictions.tolist(),
            'actuals': actuals.tolist()
        }
    
    def train_model(self, num_epochs=3, learning_rate=3e-4):
        """
        Train the model on YOUR specific dataset
        This learns YOUR grading patterns, not just keyword matching
        """
        print(f"\n🚀 Starting Custom Model Training")
        print(f"This will learn YOUR specific grading patterns from {len(self.train_dataset)} examples")
        print(f"Epochs: {num_epochs}, Learning Rate: {learning_rate}")
        print("="*60)
        
        # Setup optimizer
        optimizer = AdamW(self.model.parameters(), lr=learning_rate)
        
        # Training loop
        self.model.train()
        best_mae = float('inf')
        training_history = []
        
        for epoch in range(num_epochs):
            print(f"\nEpoch {epoch+1}/{num_epochs}")
            print("-" * 40)
            
            epoch_loss = 0
            num_batches = 0
            
            # Training
            progress_bar = tqdm(self.train_loader, desc=f"Training Epoch {epoch+1}")
            
            for batch in progress_bar:
                optimizer.zero_grad()
                
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels'].to(self.device)
                
                # Forward pass
                outputs = self.model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    labels=labels
                )
                
                loss = outputs.loss
                epoch_loss += loss.item()
                num_batches += 1
                
                # Backward pass
                loss.backward()
                optimizer.step()
                
                # Update progress bar
                progress_bar.set_postfix({'loss': f'{loss.item():.4f}'})
            
            avg_loss = epoch_loss / num_batches
            print(f"Average training loss: {avg_loss:.4f}")
            
            # Evaluation
            metrics = self.evaluate_model()
            print(f"Validation MAE: {metrics['mae']:.3f}")
            print(f"Exact Match Accuracy: {metrics['exact_match']:.3f}")
            print(f"Within 1 Point Accuracy: {metrics['within_1_point']:.3f}")
            
            # Save best model
            if metrics['mae'] < best_mae:
                best_mae = metrics['mae']
                self.save_model("c:\\Users\\vinay\\Desktop\\research paper\\models\\best_custom_model")
                print(f"✅ New best model saved! MAE: {best_mae:.3f}")
            
            # Record training history
            training_history.append({
                'epoch': epoch + 1,
                'train_loss': avg_loss,
                'val_mae': metrics['mae'],
                'exact_match': metrics['exact_match'],
                'within_1_point': metrics['within_1_point']
            })
        
        print(f"\n🎉 Training completed!")
        print(f"Best validation MAE: {best_mae:.3f}")
        
        # Save training history
        with open("c:\\Users\\vinay\\Desktop\\research paper\\training_history.json", 'w') as f:
            json.dump(training_history, f, indent=2)
        
        return training_history
    
    def save_model(self, save_path):
        """Save the trained model"""
        os.makedirs(save_path, exist_ok=True)
        
        self.model.save_pretrained(save_path)
        self.tokenizer.save_pretrained(save_path)
        
        # Save training info
        info = {
            'model_type': 'T5ForConditionalGeneration',
            'base_model': 't5-small',
            'trained_on': 'Custom OS grading dataset',
            'training_samples': len(self.train_dataset),
            'validation_samples': len(self.val_dataset),
            'trained_at': datetime.now().isoformat()
        }
        
        with open(os.path.join(save_path, 'training_info.json'), 'w') as f:
            json.dump(info, f, indent=2)
        
        print(f"Model saved to {save_path}")
    
    def test_model_on_samples(self):
        """Test the trained model on some sample questions"""
        print("\n🧪 Testing trained model on sample questions...")
        
        test_cases = [
            {
                'question': 'What is multithreading?',
                'answer': 'Multithreading allows multiple threads to execute concurrently within a single process.'
            },
            {
                'question': 'Explain virtual memory',
                'answer': 'Virtual memory extends physical RAM using disk space as storage.'
            },
            {
                'question': 'What is a deadlock?',
                'answer': 'A deadlock occurs when processes are waiting for each other indefinitely.'
            }
        ]
        
        self.model.eval()
        
        for i, test in enumerate(test_cases, 1):
            input_text = f"Question: {test['question']}\\nStudent Answer: {test['answer']}\\nTask: Grade and provide feedback"
            
            # Tokenize
            input_encoding = self.tokenizer(
                input_text,
                max_length=512,
                padding='max_length',
                truncation=True,
                return_tensors='pt'
            ).to(self.device)
            
            # Generate
            with torch.no_grad():
                generated = self.model.generate(
                    input_ids=input_encoding['input_ids'],
                    attention_mask=input_encoding['attention_mask'],
                    max_length=256,
                    num_beams=4,
                    early_stopping=True,
                    temperature=0.7,
                    do_sample=True
                )
            
            # Decode
            prediction = self.tokenizer.decode(generated[0], skip_special_tokens=True)
            score = self.extract_score_from_prediction(prediction)
            
            print(f"\nTest {i}:")
            print(f"Question: {test['question']}")
            print(f"Answer: {test['answer']}")
            print(f"Model Prediction: {prediction}")
            print(f"Extracted Score: {score}/5")
            print("-" * 50)

def main():
    """Main training function"""
    print("🎓 Custom OS Answer Grading Model Trainer")
    print("This trains a T5 model specifically on YOUR grading dataset")
    print("The model will learn YOUR grading patterns and rubric")
    print("="*60)
    
    try:
        # Initialize trainer
        trainer = CustomOSGradingTrainer(model_name='t5-small')
        
        # Load data
        train_df, val_df = trainer.load_data()
        
        print(f"\n📊 Dataset Summary:")
        print(f"Training examples: {len(train_df)}")
        print(f"Validation examples: {len(val_df)}")
        
        # Show score distribution
        train_scores = train_df['score'].value_counts().sort_index()
        print(f"Score distribution: {dict(train_scores)}")
        
        # Confirm training
        print(f"\n⚠️ This will train a model specifically on YOUR grading patterns")
        print(f"Training time: ~10-20 minutes")
        
        choice = input("Do you want to proceed with training? (y/n): ")
        if choice.lower() != 'y':
            print("Training cancelled.")
            return
        
        # Train the model
        history = trainer.train_model(num_epochs=3, learning_rate=3e-4)
        
        # Test the model
        trainer.test_model_on_samples()
        
        print(f"\n🎉 SUCCESS! Your custom model is trained and ready!")
        print(f"Model saved to: models/best_custom_model")
        print(f"Training history saved to: training_history.json")
        
        print(f"\n📋 Next steps:")
        print(f"1. Use your trained model: python grading_system.py")
        print(f"2. The model now understands YOUR specific grading style")
        print(f"3. It can grade new answers based on learned patterns")
        
    except Exception as e:
        print(f"❌ Training failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
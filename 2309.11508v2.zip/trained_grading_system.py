"""
OS Grading System using YOUR custom-trained T5 model
This uses the model trained specifically on YOUR grading patterns
"""

import torch
from transformers import T5ForConditionalGeneration, T5Tokenizer
import pandas as pd
import re
from typing import Dict, List
import os
import json
from datetime import datetime

try:
    from rag_system import RAGKnowledgeBase
    RAG_AVAILABLE = True
except ImportError:
    RAG_AVAILABLE = False

class TrainedOSGradingSystem:
    """
    Grading system using YOUR custom-trained T5 model
    This model learned from YOUR specific grading examples and patterns
    """
    
    def __init__(self, model_path: str, rag_kb_path: str = None):
        """
        Initialize with your trained model
        
        Args:
            model_path: Path to YOUR trained T5 model
            rag_kb_path: Path to RAG knowledge base (optional)
        """
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        print(f"Using device: {self.device}")
        
        # Load YOUR trained model
        if os.path.exists(model_path):
            try:
                print(f"Loading YOUR trained model from {model_path}")
                self.model = T5ForConditionalGeneration.from_pretrained(model_path)
                self.tokenizer = T5Tokenizer.from_pretrained(model_path)
                self.model.to(self.device)
                self.model.eval()
                
                # Load training info if available
                info_path = os.path.join(model_path, 'training_info.json')
                if os.path.exists(info_path):
                    with open(info_path, 'r') as f:
                        self.training_info = json.load(f)
                    print(f"✅ Model trained on {self.training_info.get('training_samples', 'unknown')} examples")
                    print(f"   Trained at: {self.training_info.get('trained_at', 'unknown')}")
                else:
                    self.training_info = {}
                
                self.model_loaded = True
                print("✅ YOUR custom model loaded successfully!")
                
            except Exception as e:
                print(f"❌ Error loading trained model: {e}")
                print("Falling back to simple grading...")
                self.model_loaded = False
        else:
            print(f"❌ Trained model not found at {model_path}")
            print("Please train the model first using: python custom_model_trainer.py")
            self.model_loaded = False
        
        # Initialize RAG system if available
        self.rag_system = None
        if rag_kb_path and RAG_AVAILABLE and os.path.exists(f"{rag_kb_path}_data.pkl"):
            try:
                self.rag_system = RAGKnowledgeBase()
                self.rag_system.load_knowledge_base(rag_kb_path)
                print("✅ RAG system loaded for context enhancement")
            except Exception as e:
                print(f"⚠️ Could not load RAG system: {e}")
        
        # Grading rubric (learned by your model)
        self.rubric = {
            0: "Completely incorrect or irrelevant answer",
            1: "Mostly incorrect with minimal understanding shown", 
            2: "Partially correct but missing key concepts or has significant errors",
            3: "Generally correct but lacks detail or has minor errors",
            4: "Mostly correct and well-explained with minor gaps",
            5: "Excellent answer that is complete, accurate, and well-explained"
        }
    
    def extract_score_and_feedback(self, prediction: str) -> Dict:
        """Extract score and feedback from model prediction"""
        # Extract score using multiple patterns
        score_patterns = [
            r'Score:\s*(\d+)/5',
            r'Score:\s*(\d+)',
            r'(\d+)/5',
            r'scored?\s*(\d+)',
            r'grade[d]?\s*(\d+)'
        ]
        
        score = 0
        for pattern in score_patterns:
            match = re.search(pattern, prediction, re.IGNORECASE)
            if match:
                score = int(match.group(1))
                score = min(max(score, 0), 5)  # Ensure 0-5 range
                break
        
        # Extract feedback
        feedback_patterns = [
            r'Feedback:\s*(.+?)(?:\n|$)',
            r'feedback[:\s]+(.+?)(?:\n|$)',
            r'(?:Score:\s*\d+/5\s*)(.+)',
            r'(?:Score:\s*\d+\s*)(.+)'
        ]
        
        feedback = ""
        for pattern in feedback_patterns:
            match = re.search(pattern, prediction, re.IGNORECASE | re.DOTALL)
            if match:
                feedback = match.group(1).strip()
                break
        
        if not feedback:
            feedback = prediction.strip()
        
        return {
            'score': score,
            'feedback': feedback,
            'raw_prediction': prediction
        }
    
    def grade_answer_with_trained_model(self, question: str, student_answer: str, 
                                      include_context: bool = True) -> Dict:
        """
        Grade using YOUR trained model - this understands YOUR grading patterns
        """
        if not self.model_loaded:
            return self.fallback_grading(question, student_answer)
        
        # Get RAG context if available
        context = ""
        if include_context and self.rag_system:
            context = self.rag_system.get_context_for_question(question, max_context_length=300)
        
        # Format input exactly like training data
        input_text = f"Question: {question}\\nStudent Answer: {student_answer}"
        if context:
            input_text += f"\\nContext: {context}"
        input_text += "\\nTask: Grade and provide feedback"
        
        # Tokenize
        input_encoding = self.tokenizer(
            input_text,
            max_length=512,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        ).to(self.device)
        
        # Generate prediction using YOUR trained model
        with torch.no_grad():
            generated = self.model.generate(
                input_ids=input_encoding['input_ids'],
                attention_mask=input_encoding['attention_mask'],
                max_length=256,
                num_beams=4,
                early_stopping=True,
                temperature=0.7,
                do_sample=True,
                pad_token_id=self.tokenizer.pad_token_id
            )
        
        # Decode prediction
        prediction = self.tokenizer.decode(generated[0], skip_special_tokens=True)
        
        # Extract score and feedback
        result = self.extract_score_and_feedback(prediction)
        
        return {
            'question': question,
            'student_answer': student_answer,
            'score': result['score'],
            'max_score': 5,
            'feedback': result['feedback'],
            'context_used': context,
            'raw_prediction': result['raw_prediction'],
            'graded_by': 'trained_model',
            'model_info': self.training_info,
            'timestamp': datetime.now().isoformat()
        }
    
    def fallback_grading(self, question: str, student_answer: str) -> Dict:
        """Fallback grading if trained model not available"""
        return {
            'question': question,
            'student_answer': student_answer,
            'score': 0,
            'max_score': 5,
            'feedback': "Trained model not available. Please train the model first.",
            'context_used': "",
            'raw_prediction': "Model not loaded",
            'graded_by': 'fallback',
            'timestamp': datetime.now().isoformat()
        }
    
    def grade_batch(self, questions_answers: List[Dict]) -> List[Dict]:
        """Grade multiple answers using your trained model"""
        results = []
        
        print(f"Grading {len(questions_answers)} answers with YOUR trained model...")
        
        for i, qa in enumerate(questions_answers):
            print(f"Grading {i+1}/{len(questions_answers)}: {qa['question'][:50]}...")
            
            result = self.grade_answer_with_trained_model(
                question=qa['question'],
                student_answer=qa['student_answer']
            )
            
            results.append(result)
        
        return results
    
    def compare_with_actual_grades(self, test_file: str = None):
        """Compare model predictions with actual grades from your dataset"""
        if not self.model_loaded:
            print("❌ Trained model not available for comparison")
            return
        
        if test_file is None:
            test_file = "c:\\Users\\vinay\\Desktop\\research paper\\test_data.csv"
        
        if not os.path.exists(test_file):
            print(f"❌ Test file not found: {test_file}")
            return
        
        print(f"📊 Comparing model predictions with actual grades...")
        
        # Load test data
        test_df = pd.read_csv(test_file)
        
        predictions = []
        actuals = []
        detailed_results = []
        
        for _, row in test_df.iterrows():
            # Get model prediction
            result = self.grade_answer_with_trained_model(
                question=row['question'],
                student_answer=row['student_answer']
            )
            
            predicted_score = result['score']
            actual_score = row['score']
            
            predictions.append(predicted_score)
            actuals.append(actual_score)
            
            detailed_results.append({
                'question': row['question'],
                'student_answer': row['student_answer'],
                'predicted_score': predicted_score,
                'actual_score': actual_score,
                'difference': abs(predicted_score - actual_score),
                'model_feedback': result['feedback']
            })
        
        # Calculate metrics
        predictions = np.array(predictions)
        actuals = np.array(actuals)
        
        mae = np.mean(np.abs(predictions - actuals))
        exact_match = np.mean(predictions == actuals)
        within_1 = np.mean(np.abs(predictions - actuals) <= 1)
        
        print(f"\n📈 Model Performance on Test Set:")
        print(f"Mean Absolute Error: {mae:.3f}")
        print(f"Exact Match Accuracy: {exact_match:.3f} ({exact_match*100:.1f}%)")
        print(f"Within 1 Point Accuracy: {within_1:.3f} ({within_1*100:.1f}%)")
        
        # Show some examples
        print(f"\n📝 Sample Predictions:")
        for i, result in enumerate(detailed_results[:3]):
            print(f"\nExample {i+1}:")
            print(f"Question: {result['question'][:80]}...")
            print(f"Predicted: {result['predicted_score']}/5")
            print(f"Actual: {result['actual_score']}/5")
            print(f"Difference: {result['difference']}")
            print(f"Feedback: {result['model_feedback'][:100]}...")
        
        # Save detailed results
        results_file = "c:\\Users\\vinay\\Desktop\\research paper\\model_evaluation_results.json"
        evaluation_data = {
            'metrics': {
                'mae': float(mae),
                'exact_match_accuracy': float(exact_match),
                'within_1_point_accuracy': float(within_1)
            },
            'detailed_results': detailed_results,
            'evaluated_at': datetime.now().isoformat()
        }
        
        with open(results_file, 'w') as f:
            json.dump(evaluation_data, f, indent=2)
        
        print(f"\n💾 Detailed results saved to: {results_file}")
        
        return evaluation_data
    
    def interactive_grading(self):
        """Interactive grading with your trained model"""
        print("🎓 OS Answer Grading System - Using YOUR Trained Model")
        
        if not self.model_loaded:
            print("❌ Trained model not available!")
            print("Please train the model first: python custom_model_trainer.py")
            return
        
        print(f"✅ Using model trained on {self.training_info.get('training_samples', 'unknown')} examples")
        print("This model learned YOUR specific grading patterns!")
        print("Enter 'quit' to exit")
        print("="*60)
        
        while True:
            print("\\n" + "-"*50)
            question = input("Enter the question: ").strip()
            
            if question.lower() == 'quit':
                break
            
            student_answer = input("Enter the student's answer: ").strip()
            
            if student_answer.lower() == 'quit':
                break
            
            print("\\nGrading with YOUR trained model...")
            result = self.grade_answer_with_trained_model(question, student_answer)
            
            print(f"\\n{'='*60}")
            print("GRADING RESULT (From YOUR Trained Model)")
            print(f"{'='*60}")
            print(f"Score: {result['score']}/5")
            print(f"\\nFeedback:")
            print(result['feedback'])
            
            if result['context_used']:
                print(f"\\nRelevant Context Used:")
                print(result['context_used'][:200] + "..." if len(result['context_used']) > 200 else result['context_used'])
            
            print(f"\\nModel Info: Trained on {self.training_info.get('training_samples', 'unknown')} examples")
            print(f"{'='*60}")

def main():
    """Main function"""
    print("🚀 OS Answer Grading System - Using YOUR Trained Model")
    print("="*60)
    
    # Initialize with your trained model
    model_path = "c:\\Users\\vinay\\Desktop\\research paper\\models\\best_custom_model"
    rag_kb_path = "c:\\Users\\vinay\\Desktop\\research paper\\rag_kb"
    
    grading_system = TrainedOSGradingSystem(model_path, rag_kb_path)
    
    if not grading_system.model_loaded:
        print("\\n❌ No trained model found!")
        print("Please train your model first:")
        print("python custom_model_trainer.py")
        return
    
    # Test with sample questions
    print("\\n🧪 Testing with sample questions...")
    test_questions = [
        {
            'question': "What is multithreading and explain its benefits?",
            'student_answer': "Multithreading allows a program to execute multiple threads concurrently. Benefits include better resource utilization and improved responsiveness."
        },
        {
            'question': "Explain the difference between kernel mode and user mode.",
            'student_answer': "Kernel mode has full access to hardware while user mode has restricted access for security."
        }
    ]
    
    results = grading_system.grade_batch(test_questions)
    
    # Display results
    for i, result in enumerate(results, 1):
        print(f"\\n{'='*50}")
        print(f"TEST {i} - Graded by YOUR Trained Model")
        print(f"{'='*50}")
        print(f"Question: {result['question']}")
        print(f"Answer: {result['student_answer']}")
        print(f"Score: {result['score']}/5")
        print(f"Feedback: {result['feedback']}")
    
    # Compare with test set if available
    grading_system.compare_with_actual_grades()
    
    # Interactive session
    choice = input("\\nWould you like to start interactive grading? (y/n): ")
    if choice.lower() == 'y':
        grading_system.interactive_grading()

if __name__ == "__main__":
    import numpy as np
    main()
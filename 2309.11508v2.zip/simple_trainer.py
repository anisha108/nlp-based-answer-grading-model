"""
Simplified Custom Model Trainer for OS Answer Grading
Trains specifically on YOUR dataset to learn YOUR grading patterns
"""

import os
import sys
import json
from datetime import datetime

def check_dependencies():
    """Check if all required packages are available"""
    print("Checking dependencies...")
    
    try:
        import torch
        print(f"✅ PyTorch: {torch.__version__}")
    except ImportError:
        print("❌ PyTorch not found. Install with: pip install torch")
        return False
    
    try:
        import transformers
        print(f"✅ Transformers: {transformers.__version__}")
    except ImportError:
        print("❌ Transformers not found. Install with: pip install transformers")
        return False
    
    try:
        import pandas as pd
        print(f"✅ Pandas: {pd.__version__}")
    except ImportError:
        print("❌ Pandas not found. Install with: pip install pandas")
        return False
    
    return True

def check_data():
    """Check if training data is available"""
    print("\nChecking training data...")
    
    if not os.path.exists("train_data.csv"):
        print("❌ train_data.csv not found. Run data_preprocessor.py first.")
        return False
    
    if not os.path.exists("val_data.csv"):
        print("❌ val_data.csv not found. Run data_preprocessor.py first.")
        return False
    
    try:
        import pandas as pd
        train_df = pd.read_csv("train_data.csv")
        val_df = pd.read_csv("val_data.csv")
        
        print(f"✅ Training data: {len(train_df)} samples")
        print(f"✅ Validation data: {len(val_df)} samples")
        
        # Check required columns
        required_cols = ['input_text', 'target_text', 'question', 'student_answer', 'score']
        missing_cols = [col for col in required_cols if col not in train_df.columns]
        
        if missing_cols:
            print(f"❌ Missing columns: {missing_cols}")
            return False
        
        print("✅ All required columns present")
        return True
        
    except Exception as e:
        print(f"❌ Error loading data: {e}")
        return False

def run_training():
    """Run the actual training"""
    print("\n" + "="*60)
    print("🚀 STARTING CUSTOM MODEL TRAINING")
    print("This will train a T5 model on YOUR specific grading patterns")
    print("="*60)
    
    try:
        # Import training modules
        import torch
        from torch.utils.data import Dataset, DataLoader
        import pandas as pd
        import numpy as np
        from transformers import T5ForConditionalGeneration, T5Tokenizer, AdamW
        import re
        from tqdm import tqdm
        
        # Set device
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        print(f"Using device: {device}")
        
        # Load data
        print("Loading training data...")
        train_df = pd.read_csv("train_data.csv")
        val_df = pd.read_csv("val_data.csv")
        
        # Initialize model
        print("Loading T5-small model...")
        tokenizer = T5Tokenizer.from_pretrained('t5-small')
        model = T5ForConditionalGeneration.from_pretrained('t5-small')
        model.to(device)
        
        # Simple dataset class
        class SimpleDataset(Dataset):
            def __init__(self, df, tokenizer):
                self.data = df.reset_index(drop=True)
                self.tokenizer = tokenizer
            
            def __len__(self):
                return len(self.data)
            
            def __getitem__(self, idx):
                row = self.data.iloc[idx]
                
                input_text = str(row['input_text'])
                target_text = str(row['target_text'])
                
                # Tokenize
                input_encoding = self.tokenizer(
                    input_text, max_length=512, padding='max_length', 
                    truncation=True, return_tensors='pt'
                )
                target_encoding = self.tokenizer(
                    target_text, max_length=256, padding='max_length', 
                    truncation=True, return_tensors='pt'
                )
                
                return {
                    'input_ids': input_encoding['input_ids'].flatten(),
                    'attention_mask': input_encoding['attention_mask'].flatten(),
                    'labels': target_encoding['input_ids'].flatten()
                }
        
        # Create datasets
        train_dataset = SimpleDataset(train_df, tokenizer)
        val_dataset = SimpleDataset(val_df, tokenizer)
        
        # Create data loaders
        train_loader = DataLoader(train_dataset, batch_size=1, shuffle=True)  # Small batch for stability
        val_loader = DataLoader(val_dataset, batch_size=1, shuffle=False)
        
        # Setup training
        optimizer = AdamW(model.parameters(), lr=3e-4)
        num_epochs = 3
        
        print(f"Training for {num_epochs} epochs on {len(train_dataset)} examples...")
        
        # Training loop
        model.train()
        best_loss = float('inf')
        
        for epoch in range(num_epochs):
            print(f"\nEpoch {epoch+1}/{num_epochs}")
            
            epoch_loss = 0
            progress_bar = tqdm(train_loader, desc=f"Training")
            
            for batch in progress_bar:
                optimizer.zero_grad()
                
                input_ids = batch['input_ids'].to(device)
                attention_mask = batch['attention_mask'].to(device)
                labels = batch['labels'].to(device)
                
                # Forward pass
                outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
                loss = outputs.loss
                
                # Backward pass
                loss.backward()
                optimizer.step()
                
                epoch_loss += loss.item()
                progress_bar.set_postfix({'loss': f'{loss.item():.4f}'})
            
            avg_loss = epoch_loss / len(train_loader)
            print(f"Average training loss: {avg_loss:.4f}")
            
            # Save best model
            if avg_loss < best_loss:
                best_loss = avg_loss
                
                # Create models directory
                os.makedirs("models", exist_ok=True)
                save_path = "models/best_custom_model"
                os.makedirs(save_path, exist_ok=True)
                
                # Save model
                model.save_pretrained(save_path)
                tokenizer.save_pretrained(save_path)
                
                # Save training info
                training_info = {
                    'model_type': 'T5ForConditionalGeneration',
                    'base_model': 't5-small',
                    'training_samples': len(train_dataset),
                    'validation_samples': len(val_dataset),
                    'epochs_trained': epoch + 1,
                    'best_loss': float(best_loss),
                    'trained_at': datetime.now().isoformat()
                }
                
                with open(os.path.join(save_path, 'training_info.json'), 'w') as f:
                    json.dump(training_info, f, indent=2)
                
                print(f"✅ Best model saved! Loss: {best_loss:.4f}")
        
        print(f"\n🎉 Training completed successfully!")
        print(f"Model saved to: models/best_custom_model")
        print(f"Final loss: {best_loss:.4f}")
        
        # Test the model
        print("\n🧪 Testing trained model...")
        model.eval()
        
        test_input = "Question: What is multithreading? Student Answer: Multithreading allows concurrent execution. Task: Grade and provide feedback"
        
        input_encoding = tokenizer(test_input, max_length=512, padding='max_length', truncation=True, return_tensors='pt').to(device)
        
        with torch.no_grad():
            generated = model.generate(
                input_ids=input_encoding['input_ids'],
                attention_mask=input_encoding['attention_mask'],
                max_length=256,
                num_beams=4,
                early_stopping=True
            )
        
        prediction = tokenizer.decode(generated[0], skip_special_tokens=True)
        print(f"Sample prediction: {prediction}")
        
        return True
        
    except Exception as e:
        print(f"❌ Training failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main function"""
    print("🎓 Simple Custom Model Trainer")
    print("Trains T5 model on YOUR specific grading patterns")
    print("="*50)
    
    # Check dependencies
    if not check_dependencies():
        print("\n❌ Missing dependencies. Please install required packages.")
        return
    
    # Check data
    if not check_data():
        print("\n❌ Training data not ready. Please run data preprocessing first.")
        return
    
    # Confirm training
    print(f"\n⚠️ This will train a model specifically on YOUR grading patterns")
    print(f"Training time: ~10-20 minutes")
    print(f"The model will learn from YOUR 91 grading examples")
    
    choice = input("\nDo you want to proceed with training? (y/n): ")
    if choice.lower() != 'y':
        print("Training cancelled.")
        return
    
    # Run training
    success = run_training()
    
    if success:
        print(f"\n🎉 SUCCESS! Your custom model is ready!")
        print(f"\nNext steps:")
        print(f"1. Test your model: python trained_grading_system.py")
        print(f"2. Use interactive grading with YOUR trained model")
        print(f"3. The model now understands YOUR specific grading style!")
    else:
        print(f"\n❌ Training failed. Check the error messages above.")

if __name__ == "__main__":
    main()